package fr.esipe.ic.JeuPlusMoins;

public interface INbAleatoireService {
	int getNbAlea();
}
